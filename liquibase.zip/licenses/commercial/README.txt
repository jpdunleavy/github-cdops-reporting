Liquibase License Information (Used by Liquibase Commercial)
Version: 4.14.0

Liquibase ships with 3rd party components using the following licenses:

- Apache 2.0 License - https://opensource.org/licenses/Apache-2.0
- GNU Affero General Public License version 3 https://opensource.org/licenses/AGPL-3.0

Libraries and their licenses:

Apache 2.0 License
- commons-codec:commons-codec
- com.fasterxml.jackson.module:jackson-module-jaxb-annotations
- com.fasterxml.jackson.core:jackson-core
- com.fasterxml.jackson.core:jackson-databind
- com.fasterxml.jackson.core:jackson-annotations
- com.github.jsqlparser:jsqlparser (Dual licence: Apache 2.0, LGPL 2.1)
- org.liquibase:liquibase-core

GNU Affero General Public License (AGPL) version 3
- net.java.truelicense:truelicense

